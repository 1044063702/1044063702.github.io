import sys
from socket import * 

def check(ip:str, port:str):
    s = socket()
    try:
        s.connect((ip, port))
        s.close()
        print('check 成功')
    except Exception:
        print('check 失败')

if __name__ == "__main__":
    try:
        check(sys.argv[1], sys.argv[2])
    except Exception:
        print('请添加参数如：python check.py ip port')
