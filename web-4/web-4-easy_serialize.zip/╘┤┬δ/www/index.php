<!DOCTYPE html>
<html>
<head>
	<title>have fun~</title>
</head>
<body>
<!--JTNDJTNGcGhwJTBBY2xhc3MlMjBnb29kJTIwJTdCJTBBJTIwJTIwJTIwJTIwcHJvdGVjdGVkJTIwJTI0YSUzQiUwQSUwQSUyMCUyMCUyMCUyMGZ1bmN0aW9uJTIwX19jb25zdHJ1Y3QlMjglMjklMjAlN0IlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjR0aGlzLSUzRWElMjAlM0QlMjBuZXclMjBoZWxsbyUyOCUyOSUzQiUwQSUyMCUyMCUyMCUyMCU3RCUwQSUwQSUyMCUyMCUyMCUyMGZ1bmN0aW9uJTIwX19kZXN0cnVjdCUyOCUyOSUyMCU3QiUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyNHRoaXMtJTNFYS0lM0VhY3Rpb24lMjglMjklM0IlMEElMjAlMjAlMjAlMjAlN0QlMEElN0QlMEElMEFjbGFzcyUyMGhlbGxvJTIwJTdCJTBBJTIwJTIwJTIwJTIwZnVuY3Rpb24lMjBhY3Rpb24lMjglMjklMjAlN0IlMEElMjAlMjAlMjAlMjAlMjAlMjAlMjAlMjBlY2hvJTIwJTIyaGVsbG8lMjIlM0IlMEElMjAlMjAlMjAlMjAlN0QlMEElN0QlMEElMEFjbGFzcyUyMHNoZWxsJTIwJTdCJTBBJTIwJTIwJTIwJTIwcHJpdmF0ZSUyMCUyNGRhdGElM0IlMEElMjAlMjAlMjAlMjBmdW5jdGlvbiUyMGFjdGlvbiUyOCUyOSUyMCU3QiUwQSUyMCUyMCUyMCUyMCUyMCUyMCUyMCUyMGV2YWwlMjglMjR0aGlzLSUzRWRhdGElMjklM0IlMEElMjAlMjAlMjAlMjAlN0QlMEElN0QlMEElMEFAdW5zZXJpYWxpemUlMjglMjRfR0VUJTVCJTI3ZGF0YSUyNyU1RCUyOSUzQiUwQSUzRiUzRQ==-->
</body>
</html>
<?php
class good {
    protected $a;

    function __construct() {
        $this->a = new hello();
    }

    function __destruct() {
        $this->a->action();
    }
}

class hello {
    function action() {
        echo "hello";
    }
}

class shell {
    private $data;
    function action() {
        system($this->data);
    }
}

@unserialize($_GET['data']);
?>
