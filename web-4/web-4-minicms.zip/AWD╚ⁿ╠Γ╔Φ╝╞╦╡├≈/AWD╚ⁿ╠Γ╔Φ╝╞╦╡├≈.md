### 自带后门

index.php

![image-20200607183956978](D:/Documents/个人笔记/Notes/images/image-20200607183956978.png)

### 后台getshell

修改配置文件的地方过滤不严

![image-20200607185643500](D:/Documents/个人笔记/Notes/images/image-20200607185643500.png)

在后台可以getshell

![image-20200607190349774](D:/Documents/个人笔记/Notes/images/image-20200607190349774.png)

### 越权

后台conf.php判断管理员权限处有误，head.php应在最前面引用，否则任何人均可执行引用head.php之前的代码

![image-20200607190458438](D:/Documents/个人笔记/Notes/images/image-20200607190458438.png)

直接用上面的后台getshell

![image-20200607190535909](D:/Documents/个人笔记/Notes/images/image-20200607190535909.png)

### 任意文件下载

![image-20200607190854500](D:/Documents/个人笔记/Notes/images/image-20200607190854500.png)