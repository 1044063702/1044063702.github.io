    </div>
  </div>
  <div id="footer"><div id="footer_box">感谢使用 <a href="#">MiniCMS</a> 进行创作</div></div>
</body>
</html>
