<?php
$mc_config = array (
  'site_name' => '我的网站',
  'site_desc' => '又一个MiniCMS网站',
  'site_link' => 'http://'.$_SERVER['HTTP_HOST'] ,
  'user_nick' => '神秘人',
  'user_name' => 'admin',
  'user_pass' => '123',
  'comment_code' => '123'
)
?>