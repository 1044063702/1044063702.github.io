<?php
$mc_posts=array (
  'tucvj0' => 
  array (
    'id' => 'tucvj0',
    'state' => 'publish',
    'title' => '123',
    'tags' => 
    array (
      0 => '123',
    ),
    'date' => '2019-06-28',
    'time' => '09:25:59',
    'can_comment' => '1',
  ),
)
?>