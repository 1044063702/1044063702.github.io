       <!-- phpadmin footer 部分 --> </div>
    </div>
  </div>

  <script src="../js/jquery-2.1.4.min.js"></script>
  <script src="../js/bootstrap.min.js"></script>
  <script src="../js/ie10-viewport-bug-workaround.js"></script>
  <script type="text/javascript">
 $(function () {
       $('[data-toggle="tooltip"]').tooltip();
       $('[data-toggle="popover"]').popover();
    });
  </script>

</body>
</html>
<!-- phpadmin footer 部分-->