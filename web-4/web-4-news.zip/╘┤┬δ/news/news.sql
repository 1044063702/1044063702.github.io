-- MySQL dump 10.13  Distrib 5.5.59, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: news
-- ------------------------------------------------------
-- Server version	5.5.59-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `info_admin`
--
CREATE DATABASE `news`;
USE news;
DROP TABLE IF EXISTS `info_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `info_admin` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®',
  `username` varchar(30) NOT NULL COMMENT 'ç®¡ç†å‘˜åç§°ï¼Œå”¯ä¸€',
  `password` varchar(32) NOT NULL COMMENT 'ç®¡ç†å‘˜å¯†ç ',
  `email` varchar(60) NOT NULL COMMENT 'ç®¡ç†å‘˜é‚®ç®±',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='ç®¡ç†å‘˜è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `info_admin`
--

LOCK TABLES `info_admin` WRITE;
/*!40000 ALTER TABLE `info_admin` DISABLE KEYS */;
INSERT INTO `info_admin` VALUES (1,'admin','admin','yangjunalns@qq.com'),(2,'Young1','123456',''),(3,'Eric','e10adc3949ba59abbe56e057f20f883e','ad@qq.com'),(5,'absc ',' 3c9db67fd298da96a7ea6aa50da74e0',' 122143@121.com'),(6,'aa ',' 123 ',' aa@qq.com');
/*!40000 ALTER TABLE `info_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `info_article`
--

DROP TABLE IF EXISTS `info_article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `info_article` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®',
  `cId` int(10) unsigned NOT NULL COMMENT 'æ‰€å±žåˆ†ç±»id',
  `title` char(100) NOT NULL COMMENT 'æ ‡é¢˜',
  `author` char(50) NOT NULL COMMENT 'ä½œè€…',
  `description` varchar(255) NOT NULL COMMENT 'æè¿°',
  `content` text NOT NULL COMMENT 'å†…å®¹',
  `dateline` int(20) NOT NULL COMMENT 'æ—¶é—´',
  `imagePath` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COMMENT='æ–‡ç« è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `info_article`
--

LOCK TABLES `info_article` WRITE;
/*!40000 ALTER TABLE `info_article` DISABLE KEYS */;
INSERT INTO `info_article` VALUES (19,3,'聚是一团火，散是满天星',' 测试',' 聚是一团火，散是满天星 ',' 聚是一团火，散是满天星 ',1591635202,' 4bdd11f76d930daabfa209bf324d2394.jpg '),(20,6,'中国加油',' 测试',' 中国加油 ',' 中国加油中国加油中国加油中国加油中国加油 ',1591635246,'  ');
/*!40000 ALTER TABLE `info_article` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `info_cate`
--

DROP TABLE IF EXISTS `info_cate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `info_cate` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®',
  `cName` varchar(30) NOT NULL COMMENT 'åˆ†ç±»åç§°',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='åˆ†ç±»è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `info_cate`
--

LOCK TABLES `info_cate` WRITE;
/*!40000 ALTER TABLE `info_cate` DISABLE KEYS */;
INSERT INTO `info_cate` VALUES (3,'学习'),(5,'科技'),(6,'新闻');
/*!40000 ALTER TABLE `info_cate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `info_comment`
--

DROP TABLE IF EXISTS `info_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `info_comment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®',
  `articleId` int(10) unsigned NOT NULL COMMENT 'æ‰€å±žæ–‡ç« id',
  `userId` int(10) unsigned NOT NULL COMMENT 'æ‰€å±žç®¡ç†å‘˜id',
  `userName` varchar(50) NOT NULL COMMENT 'ç®¡ç†å‘˜å§“å',
  `comment` varchar(255) NOT NULL COMMENT 'å†…å®¹',
  `time` int(20) NOT NULL COMMENT 'æ—¶é—´',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8 COMMENT='è¯„è®ºè¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `info_comment`
--

LOCK TABLES `info_comment` WRITE;
/*!40000 ALTER TABLE `info_comment` DISABLE KEYS */;
INSERT INTO `info_comment` VALUES (3,9,13,' who ','æµ‹è¯•ä¸€ä¸‹ ',1432985679),(4,9,13,' who ','ç¬¬äºŒæ¬¡æµ‹è¯• ',1432987128),(5,10,13,' who ','è¿™æ˜¯æµ‹è¯• ',1432987322),(6,8,13,' who ','å°†ä¸ºæˆ‘ä»¬çš„è®¾å¤‡å¼€æ‹“ä¸€ä¸ªå…¨æ–°çš„ä¸–ç•Œï¼Œä¸€ä¸ªæ¯”ä»¥å¾€ä»»ä½•æ—¶å€™éƒ½æ›´åŠ è¿žæŽ¥åœ¨ä¸€èµ·çš„ä¸–ç•Œã€‚ã€‚ ',1432991993),(7,8,13,' who ','å°†ä¸ºæˆ‘ä»¬çš„è®¾å¤‡å¼€æ‹“ä¸€ä¸ªå…¨æ–°çš„ä¸–ç•Œï¼Œä¸€ä¸ªæ¯”ä»¥å¾€ä»»ä½•æ—¶å€™éƒ½æ›´åŠ è¿žæŽ¥åœ¨ä¸€èµ·çš„ä¸–ç•Œã€‚ã€‚ ',1432992007),(8,8,13,' who ','Now on Tapâ€é€šè¿‡ä½¿ç”¨å„æ¬¾åº”ç”¨çš„ ',1432992198),(9,8,14,' we ','ä½†æ˜¯ï¼Œå¦‚æžœâ€œNow on Tapâ€èƒ½åƒè°·æ­Œå‘¨å›› ',1432992341),(10,11,13,' who ','iOS9å’Œé•¿æœŸè½¯ä»¶æ”¯æŒ\r\n\r\niOS9ä¼ è¨€ä¸ŽiPhone6sä¼ è¨€å¦‚å½±éšå½¢ã€‚è‹¹æžœå°šæœªæ­£å¼å‘å¸ƒiOS9ï¼Œä½†è‹¹æžœå¯èƒ½åœ¨WWDCå¤§ä¼šä¸Šå‘å¸ƒiOS9ã€‚åœ¨è‹¹æžœä¸»é¢˜æ¼”è®²ç»“æŸä¹‹åŽï¼ŒiOS9å°±ä¼šå‘å¸ƒæµ‹è¯•ç‰ˆæœ¬ã€‚\r\n\r\næ®ä¼ ï¼ŒiOS9å°†ä¸ŽiPhone6sä¸€åŒå‘å¸',1433006739),(11,11,13,' who ','ä½œä¸ºiPhone6sçš„ç«žäº‰å¯¹æ‰‹ï¼ŒGalaxy Note 5ä¹Ÿæœ‰å¾ˆå¤šä¼ è¨€ã€‚æ®ä¼ ï¼ŒGalaxy Note 5å°†äºŽä»Šå¹´ç§‹å¤©å‘å¸ƒï¼Œè€Œä¸”å¾ˆå¯èƒ½æ˜¯9æœˆä»½ã€‚Galaxy Note 5å°†å†…ç½®å¾ˆå¤šæ–°åŠŸèƒ½ï¼Œå¦‚æžœè®¾è®¡èƒ½è¾¾åˆ°Galaxy S6å’ŒGalaxy S6 Edgeçš„æ°´å‡†ï¼Œå®ƒå°±å¯ä»¥å',1433007140),(12,16,13,' who ','ä¹Ÿå¯é€‚å½“æ¸…æ´ä¸€äº›å†…éƒ¨ï¼Œæ³¨æ„ä¸è¦è¿‡æ¹¿ã€‚ ',1433052573),(13,16,13,' who ','ä¹Ÿå¯é€‚å½“æ¸…æ´ä¸€äº›å†…éƒ¨ï¼Œæ³¨æ„ä¸è¦è¿‡æ¹¿ã€‚ ',1433052630),(14,16,13,' who ','ä¹Ÿå¯é€‚å½“æ¸…æ´ä¸€äº›å†…éƒ¨ï¼Œæ³¨æ„ä¸è¦è¿‡æ¹¿ã€‚ ',1433052768),(15,16,13,' who ','æµ‹è¯•æµ‹è¯•ä¸€ä¸‹ ',1433052790),(16,16,13,' who ','æµ‹è¯•æµ‹è¯•ä¸€ä¸‹ ',1433052899),(17,16,13,' who ','æµ‹è¯•æµ‹è¯•ä¸€ä¸‹ ',1433052949),(18,16,13,' who ','è¯•è¯• ',1433052958),(19,16,13,' who ','è¯•è¯• ',1433053006),(20,8,13,' who ','å½­åšç¤¾ç½‘ç«™ä»Šå¤©å‘è¡¨æ–‡ç« ç§° ',1433053055),(21,7,13,' who ','å®ƒå°†å¯ç©¿æˆ´æ¦‚å¿µç›´æŽ¥å¸¦åˆ°äº†ç»‡ç‰©ä¸Š ',1433053369),(22,7,13,' who ','å®ƒå°†å¯ç©¿æˆ´æ¦‚å¿µç›´æŽ¥å¸¦åˆ°äº†ç»‡ç‰©ä¸Š ',1433053396),(23,7,13,' who ','å®ƒå°†å¯ç©¿æˆ´æ¦‚å¿µç›´æŽ¥å¸¦åˆ°äº†ç»‡ç‰©ä¸Š ',1433053412),(24,7,13,' who ','å®ƒå°†å¯ç©¿æˆ´æ¦‚å¿µç›´æŽ¥å¸¦åˆ°äº†ç»‡ç‰©ä¸Š ',1433053460),(25,8,13,' who ','Now on Tap ',1433053583),(26,8,13,' who ','æ˜¯v ',1433053595),(27,8,13,' who ','Now on Tap ',1433053614),(28,8,13,' who ','Now on Tap ',1433053621),(29,8,13,' who ','Now on TapNow on TapNow on Tap ',1433053627),(30,8,13,' who ','$mes=$mes= ',1433053664),(31,8,13,' who ','$mes=$mes= ',1433053842),(32,8,13,' who ','	\r\nwho    2015-05-31 06:05:07\r\nNow on TapNow on TapNow on Tap	\r\nwho    2015-05-31 06:05:07\r\nNow on TapNow on TapNow on Tap ',1433053850),(33,8,13,' who ','	\r\nwho    2015-05-31 06:05:50\r\nwho 2015-05-31 06:05:07 Now on TapNow on TapNow on Tap	who 2015-05-31 06:05:07 Now on TapNow on TapNow on ',1433053872),(34,8,13,' who ','å¤§ä¼šåŽï¼Œè°·æ­Œå¯èƒ½æ­£åœ¨æ‰­è½¬è¿™ä¸€è¶‹åŠ¿ã€‚ è°·æ­Œæ¼”ç¤ºäº†å…¶Androidæ“ä½œç³»ç»Ÿçš„æ–°åŠŸèƒ½â€œNow on Tap â€ï¼Œå…è®¸å…¶GoogleNowæœåŠ¡ï¼ˆä¸“æ³¨äºŽç”¨æˆ·ç”Ÿæ´»å’Œå…´è¶£çš„è¯­éŸ³åŠ©æ‰‹ï¼‰ä½œä¸ºåº•å±‚æ¤å…¥è¯¥æ“ä½œç³»ç»Ÿï¼ŒåŸºæœ¬ä¸Šèƒ½æ”¯æŒç”¨æˆ',1433053891),(35,8,13,' who ','å¤§ä¼šåŽï¼Œè°·æ­Œå¯èƒ½æ­£åœ¨æ‰­è½¬è¿™ä¸€è¶‹åŠ¿ã€‚ è°·æ­Œæ¼”ç¤ºäº†å…¶Androidæ“ä½œç³»ç»Ÿçš„æ–°åŠŸèƒ½â€œNow on Tap â€ï¼Œå…è®¸å…¶GoogleNowæœåŠ¡ï¼ˆä¸“æ³¨äºŽç”¨æˆ·ç”Ÿæ´»å’Œå…´è¶£çš„è¯­éŸ³åŠ©æ‰‹ï¼‰ä½œä¸ºåº•å±‚æ¤å…¥è¯¥æ“ä½œç³»ç»Ÿï¼ŒåŸºæœ¬ä¸Šèƒ½æ”¯æŒç”¨æˆ',1433053909),(36,16,31,' aaaaa ','å¦‚æžœä½ çš„æ‰‹æœºå¯ ',1433058718),(37,16,31,' aaaaa ','casfsa  ',1433058852),(38,13,31,' aaaaa ','æµ‹è¯•æ³• ',1433058922),(39,17,32,' æ¨å†› ','å®¶åº­ç‰ˆ109.99ç¾Žå…ƒï¼ˆçº¦åˆäººæ°‘å¸682å…ƒï¼‰ ',1433072089),(40,18,33,' é‡Žå±±æ¤’é¸¡æ‚1 ','è°·æ­Œæ­£åŠ å¼ºä¸Žæ±½è½¦åˆ¶é€ å•†çš„åˆä½œï¼Œæ•°æ¬¾è½¦åž‹å·²ç»æ•´åˆäº†è°·æ­Œçš„Androidè½¦è½½ä¿¡æ¯å¨±ä¹ç³»ç»Ÿã€‚å®é©¬è®¡åˆ’ä¸ºæ–°ä¸€ä»£7ç³»æ±½è½¦è£…å¤‡è°·æ­Œè¿™ä¸€è½¦è½½ç³»ç»Ÿï¼Œè¯¥ç³»ç»Ÿçš„ä¿¡æ¯å¨±ä¹åŠŸèƒ½æ˜¯ç”±æ‰‹åŠ¿æ‰€æŽ§åˆ¶ã€‚ ',1433072498),(41,18,33,' é‡Žå±±æ¤’é¸¡æ‚1 ','è¿™ç§èŠ¯ç‰‡å¯ä»¥ç›‘æµ‹åŠ¨ä½œã€ ',1433072505),(42,17,33,' é‡Žå±±æ¤’é¸¡æ‚1 ','è¿™ç§èŠ¯ç‰‡å¯ä»¥ç›‘æµ‹åŠ¨ä½œã€ ',1433072516),(43,17,33,' é‡Žå±±æ¤’é¸¡æ‚1 ','åŽçš„ä¸€ä¸ªå¤šæœˆï¼ŒOEMç‰ˆå°±å¼€å§‹æ­£å¼é”€å”®äº†ã€‚ä¸è¿‡OEMç‰ˆç†è®ºä¸Šæ˜¯ä¸èƒ½å…¬å¼€é”€å”®çš„ï¼Œé‡‡è´­è¯¥ç‰ˆæœ¬çš„åº”è¯¥æ˜¯åŽŸå§‹è®¾å¤‡åˆ¶é€ å•†ï¼Œä¹Ÿå°±æ˜¯å„ä¸ªå‡ºå”®Wi ',1433072523);
/*!40000 ALTER TABLE `info_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `info_manager`
--

DROP TABLE IF EXISTS `info_manager`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `info_manager` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `webTitle` varchar(100) NOT NULL COMMENT 'ç½‘ç«™æ ‡é¢˜',
  `webMeta` varchar(255) NOT NULL COMMENT 'ç½‘ç«™metaæè¿°',
  `webDescription` text NOT NULL COMMENT 'åŽå°åŠŸèƒ½ç®€ä»‹',
  `webAuthor` varchar(50) NOT NULL COMMENT 'ç½‘ç«™ä½œè€…',
  `webBlog` varchar(50) NOT NULL COMMENT 'ä¸ªäººåšå®¢',
  `webImg` varchar(55) NOT NULL COMMENT 'ç½‘ç«™å›¾æ ‡',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='ç½‘ç«™ç®¡ç†è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `info_manager`
--

LOCK TABLES `info_manager` WRITE;
/*!40000 ALTER TABLE `info_manager` DISABLE KEYS */;
INSERT INTO `info_manager` VALUES (1,'新闻站','中国加油','新闻站','测试','frank-young.github.io','');
/*!40000 ALTER TABLE `info_manager` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `info_user`
--

DROP TABLE IF EXISTS `info_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `info_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®',
  `username` varchar(30) NOT NULL COMMENT 'ä¼šå‘˜åç§°',
  `password` varchar(32) NOT NULL COMMENT 'å¯†ç ',
  `sex` enum('ç”·','å¥³') NOT NULL DEFAULT 'ç”·' COMMENT 'æ€§åˆ«',
  `email` varchar(50) NOT NULL COMMENT 'é‚®ç®±',
  `face` varchar(50) NOT NULL COMMENT 'å¤´åƒ',
  `regTime` int(10) unsigned NOT NULL COMMENT 'æ³¨å†Œæ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8 COMMENT='ç”¨æˆ·è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `info_user`
--

LOCK TABLES `info_user` WRITE;
/*!40000 ALTER TABLE `info_user` DISABLE KEYS */;
INSERT INTO `info_user` VALUES (13,'who ',' 123456 ','ç”·',' wo@we.com ','',1432905444),(31,'aaaaa ',' aaaaa ','ç”·',' aaaaaa@qq.com ',' images/face/1.png',1433058694),(32,'æ¨å†› ',' 123456 ','ç”·',' yang@11.com ','images/face/3.png ',1433072049),(33,'é‡Žå±±æ¤’é¸¡æ‚1 ',' 123456q ','ç”·',' qwer@11.com ',' images/face/7.png',1433072448);
/*!40000 ALTER TABLE `info_user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-06-08 16:55:38
