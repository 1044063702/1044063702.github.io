<ul class="nav navbar-nav navbar-right">
	<li>
		<a href="#" data-toggle="modal" data-target="#mymodal-login">登录</a>
	</li>
	<li>
		<a href="#"  href="#" data-toggle="modal" data-target="#mymodal-reg">注册</a>
	</li>
</ul>

