### 自带后门

![image-20200609154540266](D:/Documents/个人笔记/Notes/images/image-20200609154540266.png)

### 自带后门（免杀）

`core/conn.php`

![image-20200609141832535](D:/Documents/个人笔记/Notes/images/image-20200609141832535.png)

getvar函数在同文件夹下的convention.php

![image-20200609141852471](D:/Documents/个人笔记/Notes/images/image-20200609141852471.png)

![image-20200609141918405](D:/Documents/个人笔记/Notes/images/image-20200609141918405.png)

### ssrf

`apps\admin\controller\system\UpgradeController.php:`

后台获取更新文件的位置配置不当，可以利用file协议获取到本机文件

![image-20200609152048923](D:/Documents/个人笔记/Notes/images/image-20200609152048923.png)

![image-20200609152110846](D:/Documents/个人笔记/Notes/images/image-20200609152110846.png)

构造payload

![image-20200609152131553](D:/Documents/个人笔记/Notes/images/image-20200609152131553.png)

### 利用缓存文件getshell

sitemap处有记录爬虫user_agent的位置

![image-20200609153452313](D:/Documents/个人笔记/Notes/images/image-20200609153452313.png)

跟进`mackCache`函数，多次跳转后发现：

![image-20200609160236204](D:/Documents/个人笔记/Notes/images/image-20200609160236204.png)

构造user_agent头写shell

![image-20200609154303063](D:/Documents/个人笔记/Notes/images/image-20200609154303063.png)