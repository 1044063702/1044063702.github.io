#!/bin/sh
service ssh start
a2enmod rewrite
service apache2 start
rm /var/www/html/index.html /var/www/html/phpinfo.php
chown www-data:www-data /var/www/html/* -R

cd /var/www/html
useradd ctf
echo ctf:123456 | chpasswd
sleep 2
rm -rf /run.sh

supervisord -n
touch /var/log/1.txt
tail -f /var/log/1.txt
