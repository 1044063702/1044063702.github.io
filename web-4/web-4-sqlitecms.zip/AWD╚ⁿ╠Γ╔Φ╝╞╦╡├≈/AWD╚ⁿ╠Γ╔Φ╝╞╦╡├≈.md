### 自带后门

/cms/index.php

![image-20200608224759247](D:/Documents/个人笔记/Notes/images/image-20200608224759247.png)

/index.php

![image-20200608225138918](D:/Documents/个人笔记/Notes/images/image-20200608225138918.png)

### 后台任意文件上传

没做任何过滤，传什么都行

### 后台任意文件删除

![image-20200608224502600](D:/Documents/个人笔记/Notes/images/image-20200608224502600.png)

### 文件包含

搜索关键字inculde可以发现在`\cms\includes\classes\Template.class.php`有这么一个函数，存在包含文件的地方：

![image-20200608232815680](D:/Documents/个人笔记/Notes/images/image-20200608232815680.png)

发现index.php引用了这个函数

![image-20200608223742961](D:/Documents/个人笔记/Notes/images/image-20200608223742961.png)

继续查找`template_file`的来源，发现前面包含了`cms/includes/content.inc.php`

在`cms/includes/content.inc.php`可以看到

![image-20200608223910575](D:/Documents/个人笔记/Notes/images/image-20200608223910575.png)

查看`$data`

![image-20200608223943559](D:/Documents/个人笔记/Notes/images/image-20200608223943559.png)

至此，在后台中打开缓存的情况下（默认打开），存在文件包含漏洞

![image-20200608235908359](D:/Documents/个人笔记/Notes/images/image-20200608235908359.png)