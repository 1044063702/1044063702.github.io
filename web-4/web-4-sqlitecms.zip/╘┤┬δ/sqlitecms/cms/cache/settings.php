<?php
$settings['session_prefix'] = 'phpsqlitecms_';
$settings['index_page'] = 'home';
?>