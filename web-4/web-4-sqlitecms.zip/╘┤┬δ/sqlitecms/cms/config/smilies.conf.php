<?php
$smilies = array(
array(':-)', 'smile.png'),
array(';-)', 'wink.png'),
array(':-P', 'tongue.png'),
array(':-D', 'big_smile.png'),
array(':-|', 'neutral.png'),
array(':-(', 'sad.png'),
);
