<?php

function myFunction($x,$y)
 {
  return $x + $y;
 }
 
?>
