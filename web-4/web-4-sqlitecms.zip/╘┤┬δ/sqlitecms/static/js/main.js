$(function() {

$("#menu-toggle-handle").click(function(e) { $('#nav').slideToggle('fast'); });

});
