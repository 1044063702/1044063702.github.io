<?php
header('Location: public');
