### 自带后门

![image-20200608202550975](D:/Documents/个人笔记/Notes/images/image-20200608202550975.png)

自带后门2

![image-20200608203720063](D:/Documents/个人笔记/Notes/images/image-20200608203720063.png)

### 报错注入

search.php过滤不严格，可以通过报错注入读文件（sql注入点有多处，修复时建议直接从数据库查询处过滤掉危险函数）

![image-20200608205443947](D:/Documents/个人笔记/Notes/images/image-20200608205443947.png)

![image-20200608193915410](D:/Documents/个人笔记/Notes/images/image-20200608193915410.png)

### 文件包含

投票生成柱线图的地方，有一个LoadImg函数

![image-20200608202015704](D:/Documents/个人笔记/Notes/images/image-20200608202015704.png)

跟进查看，发现可以读文件

![image-20200608202028307](D:/Documents/个人笔记/Notes/images/image-20200608202028307.png)

触发这个函数的条件是投票的标题开头需为'/'

![image-20200608202122287](D:/Documents/个人笔记/Notes/images/image-20200608202122287.png)

利用sql注入实现文件读取（也可以专门插入一条开头为/的数据）

```sql
-1%27%20union%20select%20"/flag",2,3%23
```

