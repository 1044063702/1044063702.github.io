<?php
	/**
	 *@Author:       anshao
	 *@Date:         Sep 3, 2012
	 *@Encoding:     UTF-8
	 *@Link:         http://anshao.net
	 *@CopyRight:    Anshao
	 */
	 

?>
<div id="nav">
	<ul>
		<li>
			<a href="../index.php">前台首页</a>
			<a href="index.php">后台首页</a>
			<a href="vote_manager.php">投票主题管理</a>
			<a href="guest_manager.php">留言管理</a>
			<a href="notice_manager.php">网站公告管理</a>
			<a href="logout.php" id="logout">退出登录</a>
		</li>
	</ul>
</div>