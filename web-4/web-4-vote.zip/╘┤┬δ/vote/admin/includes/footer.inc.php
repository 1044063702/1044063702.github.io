<?php
	/**
	 *@Author:       anshao
	 *@Date:         Sep 3, 2012
	 *@Encoding:     UTF-8
	 *@Link:         http://anshao.net
	 *@CopyRight:    Anshao
	 */
	 
	 
?>
<div id="footer">
	<p class="p1" >@CopyRight Anshao 2018-9-3</p>
	<p class="p2" >&copy;<a href="http://anshao.net" title="anshao.net" >anshao.net</a>&nbsp;&nbsp;邮箱:<a href="mailto:root@anshao.net"  title="邮箱" >root@anshao.net</a></p>
</div>