<?php
	/**
	 *@Author:       anshao
	 *@Date:         Sep 3, 2012
	 *@Encoding:     UTF-8
	 *@Link:         http://anshao.net
	 *@CopyRight:    Anshao
	 */
	 
	 
?>
<div id="main-top">
	<p>欢迎(管理员:<span class="blue"><?php echo $_SESSION['user']; ?></span>&nbsp;&nbsp;Ip:<span class="blue"><?php echo $_SERVER['REMOTE_ADDR']; ?></span>),现在时间是:<span class="blue"><?php echo date('Y-m-d',time()); ?></span></p>
</div>