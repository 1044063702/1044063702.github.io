SET NAMES utf8;
SET FOREIGN_KEY_CHECKS = 0;
create ueser 'web1'@'localhost' IDENTIFIED BY 'password';
DROP DATABASE IF EXISTS `fakebook`;
CREATE DATABASE fakebook;
USE fakebook;
DROP TABLE IF EXISTS `file`;
CREATE TABLE `users` (
	`no` INT NOT NULL AUTO_INCREMENT ,
	`username` VARCHAR(100) NOT NULL ,
	`passwd` VARCHAR(128) NOT NULL ,
	`data` TEXT NOT NULL ,
	PRIMARY KEY (`no`)
)
grant all on fakebook.* to 'web1'@'localhost'
