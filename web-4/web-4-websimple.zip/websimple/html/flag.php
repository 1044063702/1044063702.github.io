<?php

$flag = "flag{26a3a526-c18e-4eb5-9b47-398598c6d86b}";
exit(0);
