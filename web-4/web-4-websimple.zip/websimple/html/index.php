<?php session_start(); ?>
<?php require_once 'db.php'; ?>
<?php require_once 'user.php'; ?>
<?php


 ini_set("display_errors", 0);

error_reporting(E_ALL ^ E_NOTICE);

error_reporting(E_ALL ^ E_WARNING);
$flag = "FLAG{flag is in your mind}";

$db = new DB();
$user = new UserInfo();

?>
<!doctype html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Fakebook</title>

    <?php include 'bootstrap.php'; ?>

</head>
<body>
<div class="container">
    <h1>你的信息</h1>
    <?php

    if (!isset($_SESSION['username'])) {
        $message = "<div class='row'>";
        $message .= "<div class='col-md-2'><a href='login.php' class='btn btn-success'>登陆</a></div>";
        $message .= "<div class='col-md-2'><a href='join.php' class='btn btn-info'>登记博客信息</a></div>";
        $message .= "</div>";

        echo $message;
    }


    ?>
    <p>共享你的博客<code>资料</code>.</p>

    <table class="table">
        <tr>
            <th>#</th>
            <th>名字</th>
            <th>手机号</th>
            <th>博客地址</th>
        </tr>
        <?php

        foreach ($db->getAllUsers() as $user)
        {
            $data = unserialize($user['data']);

            echo "<tr>";
            echo "<td>{$user['no']}</td>";
            echo "<td><a href='view.php?no={$user['no']}'>{$user['username']}</a></td>";
            echo "<td>{$data->age}</td>";
            echo "<td>{$data->blog}</td>";
            echo "</tr>\n";
        }

        ?>
    </table>
</div>
</body>
</html>
