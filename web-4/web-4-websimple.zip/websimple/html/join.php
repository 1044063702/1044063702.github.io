<!doctype html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>注册</title>

    <?php include 'bootstrap.php'; ?>

</head>
<body>
<div class="container">
    <h1>注册信息</h1>
    <div class="form-group">
        <form action="join.ok.php" method="post">
            <div class="row">
                <div class="col-md-1">
                   用户名: 
                </div>
                <div class="col-md-4">
                    <input type="text" name="username" maxlength="100" class="form-control">
                </div>
            </div>

            <div class="row">
                <div class="col-md-1">
                    密码 :
                </div>
                <div class="col-md-4">
                    <input type="password" name="passwd" class="form-control">
                </div>
            </div>

            <div class="row">
                <div class="col-md-1">
                    手机号:
                </div>
                <div class="col-md-4">
                    <input type="text" name="age" class="form-control">
                </div>
            </div>

            <div class="row">
                <div class="col-md-1">
                    博客地址 :
                </div>
                <div class="col-md-4">
                    <input type="text" name="blog" class="form-control">
                </div>
            </div>

            <div class="row">
                <input type="submit" value="注册" class="btn btn-info">
            </div>


        </form>
    </div>
</div>
</body>
</html>
