<!doctype html>
<html lang=ko>
<head>
    <meta charset=UTF-8>
    <meta name=viewport
          content=width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0>
    <meta http-equiv=X-UA-Compatible content=ie=edge>
    <title>登陆页面</title>

    <?php include 'bootstrap.php';?>

</head>
<body>

<div class=container>
    <h1>登陆页面</h1>
    <form action=login.ok.php method=post class=form-group>
        <div class=row>
            <div class=col-md-1>
                用户名
            </div>
            <div class=col-md-4>
                <input type=text name=username class=form-control>
            </div>
        </div>
        <div class=row>
            <div class=col-md-1>
                密码
            </div>
            <div class=col-md-4>
                <input type=password name=passwd class=form-control>
            </div>
        </div>
        <div class=row>
            <input type=submit value="登陆" class=btn btn-info>
        </div>
    </form>
</div>
</body>
</html>
