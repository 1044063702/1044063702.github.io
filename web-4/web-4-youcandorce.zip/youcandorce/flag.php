<?php
$flag="flag{3c74fc4b-4c15-4e86-b4a7-450dd7e41dcb}";
echo "Get it!";
