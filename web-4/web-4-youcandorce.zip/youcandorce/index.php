<?php
    $dir = '/var/www/html/' . md5("slretx" . $_SERVER['REMOTE_ADDR']);
    @mkdir($dir);
    @chdir($dir);
    if (isset($_GET['cmd']) && strlen($_GET['cmd']) <= 5) {
        @exec($_GET['cmd']);
    } elseif (isset($_GET['reset'])) {
        @exec('/bin/rm -rf ' . $dir);
    }
    highlight_file(__FILE__);
