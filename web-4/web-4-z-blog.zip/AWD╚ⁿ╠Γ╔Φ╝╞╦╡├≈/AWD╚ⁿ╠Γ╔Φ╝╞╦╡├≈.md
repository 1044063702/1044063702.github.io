### 自带后门

第一个：![image-20200608144433827](D:/Documents/个人笔记/Notes/images/image-20200608144433827.png)

![image-20200608144244279](D:/Documents/个人笔记/Notes/images/image-20200608144244279.png)

第二个：`index.php`

![image-20200608144423219](D:/Documents/个人笔记/Notes/images/image-20200608144423219.png)

### xxe任意文件读取

审计源码，发现漏洞函数

![image-20200608142450452](D:/Documents/个人笔记/Notes/images/image-20200608142450452.png)

![image-20200608142422458](D:/Documents/个人笔记/Notes/images/image-20200608142422458.png)

在此处调用

![image-20200608142504962](D:/Documents/个人笔记/Notes/images/image-20200608142504962.png)

![image-20200608142514235](D:/Documents/个人笔记/Notes/images/image-20200608142514235.png)

构造payload

![image-20200608142946123](D:/Documents/个人笔记/Notes/images/image-20200608142946123.png)

### 任意文件读取

![image-20200608153122142](D:/Documents/个人笔记/Notes/images/image-20200608153122142.png)

![image-20200608153115729](D:/Documents/个人笔记/Notes/images/image-20200608153115729.png)

主题设置处有任意文件读取，需要登录，并且满足一下三个参数：

`act=color`

![image-20200608153247966](D:/Documents/个人笔记/Notes/images/image-20200608153247966.png)

POST`PostCOLORON`不为空

`css`为要读取的文件

