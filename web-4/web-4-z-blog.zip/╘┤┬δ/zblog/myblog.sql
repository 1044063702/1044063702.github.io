/*
 Navicat Premium Data Transfer

 Source Server         : phpstudy
 Source Server Type    : MySQL
 Source Server Version : 50726
 Source Host           : localhost:3306
 Source Schema         : myblog

 Target Server Type    : MySQL
 Target Server Version : 50726
 File Encoding         : 65001

 Date: 08/06/2020 15:34:53
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;
CREATE DATABASE `zblog`;
USE zblog;
-- ----------------------------
-- Table structure for zbp_category
-- ----------------------------
DROP TABLE IF EXISTS `zbp_category`;
CREATE TABLE `zbp_category`  (
  `cate_ID` int(11) NOT NULL AUTO_INCREMENT,
  `cate_Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `cate_Order` int(11) NOT NULL DEFAULT 0,
  `cate_Type` int(11) NOT NULL DEFAULT 0,
  `cate_Count` int(11) NOT NULL DEFAULT 0,
  `cate_Alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `cate_Intro` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `cate_RootID` int(11) NOT NULL DEFAULT 0,
  `cate_ParentID` int(11) NOT NULL DEFAULT 0,
  `cate_Template` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `cate_LogTemplate` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `cate_Meta` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`cate_ID`) USING BTREE,
  INDEX `zbp_cate_Order`(`cate_Order`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of zbp_category
-- ----------------------------
INSERT INTO `zbp_category` VALUES (1, '未分类', 0, 0, 1, 'uncategorized', '', 0, 0, '', '', '');

-- ----------------------------
-- Table structure for zbp_comment
-- ----------------------------
DROP TABLE IF EXISTS `zbp_comment`;
CREATE TABLE `zbp_comment`  (
  `comm_ID` int(11) NOT NULL AUTO_INCREMENT,
  `comm_LogID` int(11) NOT NULL DEFAULT 0,
  `comm_IsChecking` tinyint(4) NOT NULL DEFAULT 0,
  `comm_RootID` int(11) NOT NULL DEFAULT 0,
  `comm_ParentID` int(11) NOT NULL DEFAULT 0,
  `comm_AuthorID` int(11) NOT NULL DEFAULT 0,
  `comm_Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `comm_Email` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `comm_HomePage` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `comm_Content` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `comm_PostTime` int(11) NOT NULL DEFAULT 0,
  `comm_IP` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `comm_Agent` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `comm_Meta` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`comm_ID`) USING BTREE,
  INDEX `zbp_comm_LRI`(`comm_LogID`, `comm_RootID`, `comm_IsChecking`) USING BTREE,
  INDEX `zbp_comm_IsChecking`(`comm_IsChecking`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of zbp_comment
-- ----------------------------

-- ----------------------------
-- Table structure for zbp_config
-- ----------------------------
DROP TABLE IF EXISTS `zbp_config`;
CREATE TABLE `zbp_config`  (
  `conf_ID` int(11) NOT NULL AUTO_INCREMENT,
  `conf_Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `conf_Value` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`conf_ID`) USING BTREE,
  INDEX `zbp_conf_Name`(`conf_Name`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of zbp_config
-- ----------------------------
INSERT INTO `zbp_config` VALUES (1, 'cache', 'a:20:{s:16:\"sidebars_default\";s:142:\"{\"1\":\"calendar|controlpanel|catalog|searchpanel|comments|archives|favorite|link|misc\",\"2\":\"\",\"3\":\"\",\"4\":\"\",\"5\":\"\",\"6\":\"\",\"7\":\"\",\"8\":\"\",\"9\":\"\"}\";s:12:\"sidebars_Zit\";s:196:\"{\"1\":\"calendar|archives|controlpanel|catalog|favorite|link|misc\",\"2\":\"calendar|catalog|archives|previous\",\"3\":\"catalog|previous|comments\",\"4\":\"comments\",\"5\":\"comments\",\"6\":\"\",\"7\":\"\",\"8\":\"\",\"9\":\"\"}\";s:14:\"sidebars_tpure\";s:135:\"{\"1\":\"controlpanel|catalog|comments\",\"2\":\"previous|tags\",\"3\":\"catalog|tags|comments\",\"4\":\"tags\",\"5\":\"tags\",\"6\":\"\",\"7\":\"\",\"8\":\"\",\"9\":\"\"}\";s:13:\"templates_md5\";s:32:\"2a58e3c0b900a2c8e0a4b77cd61ddf92\";s:19:\"success_updated_app\";s:0:\"\";s:19:\"normal_article_nums\";s:1:\"1\";s:16:\"top_post_array_0\";s:6:\"a:0:{}\";s:16:\"all_comment_nums\";i:0;s:18:\"check_comment_nums\";i:0;s:19:\"normal_comment_nums\";i:0;s:16:\"reload_statistic\";s:906:\"<tr><td class=\'td20\'>当前用户</td><td class=\'td30\'><a href=\'../cmd.php?act=misc&type=vrs\' target=\'_blank\'>{$zbp->user->Name}</a></td><td class=\'td20\'>当前版本</td><td class=\'td30\'>{$zbp->version}</td></tr><tr><td class=\'td20\'>文章总数</td><td>1</td><td>分类总数</td><td>1</td></tr><tr><td class=\'td20\'>页面总数</td><td>1</td><td>标签总数</td><td>0</td></tr><tr><td class=\'td20\'>评论总数</td><td>0</td><td>浏览总数</td><td>0</td></tr><tr><td class=\'td20\'>当前主题</td><td>{$zbp->theme}/{$zbp->style} {$theme_version}</td><td>用户总数</td><td>1</td></tr><tr><td class=\'td20\'>XML-RPC协议地址</td><td>{#ZC_BLOG_HOST#}zb_system/xml-rpc/index.php</td><td>系统环境</td><td><a href=\'../cmd.php?act=misc&type=phpinfo\' target=\'_blank\'>{$system_environment}</a></td></tr><script type=\"text/javascript\">$(\'#statistic\').attr(\'title\',\'1970-01-01T08:00:00+08:00\');</script>\";s:21:\"reload_statistic_time\";i:1591595876;s:18:\"system_environment\";s:80:\"WINNT10.0; Apache2.4.39; PHP7.3.4x64; mysqli5.7.26; curl; OpenSSL1.1.1b26Feb2019\";s:16:\"all_article_nums\";s:1:\"1\";s:13:\"all_page_nums\";s:1:\"1\";s:17:\"all_category_nums\";s:1:\"1\";s:13:\"all_view_nums\";s:1:\"0\";s:12:\"all_tag_nums\";s:1:\"0\";s:17:\"reload_updateinfo\";s:1502:\"<tr><td><p><a href=\"https://blog.zblogcn.com/2020/06/01/110/\" target=\"_blank\"><b>滴滴滴，发车了！Z-BlogPHP 1.6.4 Valyria发布了! (2020-6-1)</b></a></p>\n\n<p>[Wiki]  \n<a href=\"https://wiki.zblogcn.com/doku.php?id=zblogphp:changelog\" target=\"_blank\">ZBlogPHP详细更新日志</a>\n    \n<a href=\"https://wiki.zblogcn.com/doku.php?id=zblogphp:development\" target=\"_blank\">ZBlogPHP应用开发指南</a>\n    \n<a href=\"https://wiki.zblogcn.com/doku.php?id=zblogphp:development:migration:1.5_-_1.6\" target=\"_blank\">开发者更新指南</a>\n</p>\n\n<p>[故障处理]  \n<a href=\"https://wiki.zblogcn.com/doku.php?id=zblogphp:failure:forgetpassword\" target=\"_blank\">ZBlogPHP密码找回工具</a>\n    \n<a href=\"https://wiki.zblogcn.com/doku.php?id=zblogphp:failure:permanentdomainerror\" target=\"_blank\">固定域名出错</a>\n    \n<a href=\"https://wiki.zblogcn.com/doku.php?id=zblogphp:failure:cannotemoji\" target=\"_blank\">不能发Emoji表情</a>\n</p>\n\n\n<p><a href=\"https://blog.zblogcn.com/2018/02/12/99/\" target=\"_blank\">大吉大利，天天吃鸡——Z-Blog祝您2018新春快乐，应用中心红包活动开始了！ (2018-2-12)</a></p>\n\n\n\n\n\n\n\n\n\n\n<p><a href=\"https://bbs.zblogcn.com/thread-83785-1-1.html\" target=\"_blank\">2014年ASP版全新发布！Z-Blog 2.2 Prism Build 140101 发布了。(2014-01-02)</a></p>\n\n<p><a href=\"https://bbs.zblogcn.com/thread-77001-1-1.html\" target=\"_blank\">Z-Blog应用中心正式上线，欢迎开发者进驻。(2013-01-01)</a></p></td></tr>\";s:22:\"reload_updateinfo_time\";i:1591597816;}');
INSERT INTO `zbp_config` VALUES (2, 'system', 'a:125:{s:19:\"ZC_CLOSE_WHOLE_SITE\";b:0;s:13:\"ZC_CLOSE_SITE\";b:0;s:12:\"ZC_BLOG_HOST\";s:34:\"h|t|t|p|:|/|/|l|o|c|a|l|h|o|s|t|/|\";s:12:\"ZC_BLOG_NAME\";s:12:\"我的博客\";s:15:\"ZC_BLOG_SUBNAME\";s:17:\"Good Luck To You!\";s:13:\"ZC_BLOG_THEME\";s:7:\"default\";s:11:\"ZC_BLOG_CSS\";s:7:\"default\";s:17:\"ZC_BLOG_COPYRIGHT\";s:44:\"Copyright Your WebSite.Some Rights Reserved.\";s:16:\"ZC_BLOG_LANGUAGE\";s:5:\"zh-CN\";s:20:\"ZC_BLOG_LANGUAGEPACK\";s:5:\"zh-cn\";s:16:\"ZC_DATABASE_TYPE\";s:6:\"mysqli\";s:14:\"ZC_SQLITE_NAME\";s:0:\"\";s:13:\"ZC_SQLITE_PRE\";s:4:\"zbp_\";s:15:\"ZC_MYSQL_SERVER\";s:9:\"localhost\";s:17:\"ZC_MYSQL_USERNAME\";s:4:\"root\";s:17:\"ZC_MYSQL_PASSWORD\";s:4:\"root\";s:13:\"ZC_MYSQL_NAME\";s:6:\"myblog\";s:16:\"ZC_MYSQL_CHARSET\";s:4:\"utf8\";s:12:\"ZC_MYSQL_PRE\";s:4:\"zbp_\";s:15:\"ZC_MYSQL_ENGINE\";s:6:\"InnoDB\";s:13:\"ZC_MYSQL_PORT\";s:4:\"3306\";s:19:\"ZC_MYSQL_PERSISTENT\";b:0;s:15:\"ZC_PGSQL_SERVER\";s:9:\"localhost\";s:17:\"ZC_PGSQL_USERNAME\";s:8:\"postgres\";s:17:\"ZC_PGSQL_PASSWORD\";s:0:\"\";s:13:\"ZC_PGSQL_NAME\";s:0:\"\";s:16:\"ZC_PGSQL_CHARSET\";s:4:\"utf8\";s:12:\"ZC_PGSQL_PRE\";s:4:\"zbp_\";s:13:\"ZC_PGSQL_PORT\";s:4:\"5432\";s:19:\"ZC_PGSQL_PERSISTENT\";b:0;s:20:\"ZC_USING_PLUGIN_LIST\";s:36:\"AppCentre|UEditor|Totoro|LinksManage\";s:13:\"ZC_BLOG_CLSID\";s:22:\"5eddd34f86e7d586611891\";s:17:\"ZC_TIME_ZONE_NAME\";s:13:\"Asia/Shanghai\";s:18:\"ZC_UPDATE_INFO_URL\";s:32:\"https://update.zblogcn.com/info/\";s:26:\"ZC_PERMANENT_DOMAIN_ENABLE\";b:0;s:13:\"ZC_DEBUG_MODE\";b:0;s:20:\"ZC_DEBUG_MODE_STRICT\";b:0;s:21:\"ZC_DEBUG_MODE_WARNING\";b:1;s:18:\"ZC_DEBUG_LOG_ERROR\";b:0;s:15:\"ZC_BLOG_PRODUCT\";s:9:\"Z-BlogPHP\";s:15:\"ZC_BLOG_VERSION\";s:26:\"1.6.0 Valyria Build 162100\";s:14:\"ZC_BLOG_COMMIT\";s:0:\"\";s:20:\"ZC_BLOG_PRODUCT_FULL\";s:0:\"\";s:20:\"ZC_BLOG_PRODUCT_HTML\";s:0:\"\";s:24:\"ZC_BLOG_PRODUCT_FULLHTML\";s:0:\"\";s:18:\"ZC_COMMENT_TURNOFF\";b:0;s:24:\"ZC_COMMENT_VERIFY_ENABLE\";b:0;s:24:\"ZC_COMMENT_REVERSE_ORDER\";b:0;s:16:\"ZC_COMMENT_AUDIT\";b:0;s:29:\"ZC_COMMENT_VALIDCMTKEY_ENABLE\";b:0;s:20:\"ZC_VERIFYCODE_STRING\";s:30:\"ABCDEFGHKMNPRSTUVWXYZ123456789\";s:19:\"ZC_VERIFYCODE_WIDTH\";i:90;s:20:\"ZC_VERIFYCODE_HEIGHT\";i:30;s:18:\"ZC_VERIFYCODE_FONT\";s:26:\"zb_system/defend/arial.ttf\";s:16:\"ZC_DISPLAY_COUNT\";i:10;s:16:\"ZC_PAGEBAR_COUNT\";i:10;s:25:\"ZC_COMMENTS_DISPLAY_COUNT\";i:100;s:23:\"ZC_DISPLAY_SUBCATEGORYS\";b:1;s:13:\"ZC_RSS2_COUNT\";i:10;s:19:\"ZC_RSS_EXPORT_WHOLE\";b:1;s:15:\"ZC_MANAGE_COUNT\";i:50;s:21:\"ZC_EMOTICONS_FILENAME\";s:4:\"face\";s:21:\"ZC_EMOTICONS_FILETYPE\";s:11:\"png|gif|jpg\";s:21:\"ZC_EMOTICONS_FILESIZE\";s:2:\"16\";s:18:\"ZC_UPLOAD_FILETYPE\";s:219:\"jpg|gif|png|jpeg|bmp|webp|psd|wmf|ico|rpm|deb|tar|gz|xz|sit|7z|bz2|zip|rar|xml|xsl|svg|svgz|rtf|doc|docx|ppt|pptx|xls|xlsx|wps|chm|txt|md|pdf|mp3|flac|ape|mp4|mkv|avi|mpg|rm|ra|rmvb|mov|wmv|wma|torrent|apk|json|zba|gzba\";s:18:\"ZC_UPLOAD_FILESIZE\";i:2;s:15:\"ZC_USERNAME_MIN\";i:3;s:15:\"ZC_USERNAME_MAX\";i:50;s:15:\"ZC_PASSWORD_MIN\";i:8;s:15:\"ZC_PASSWORD_MAX\";i:20;s:12:\"ZC_EMAIL_MAX\";i:50;s:15:\"ZC_HOMEPAGE_MAX\";i:100;s:14:\"ZC_CONTENT_MAX\";i:1000;s:20:\"ZC_ARTICLE_TITLE_MAX\";i:100;s:20:\"ZC_CATEGORY_NAME_MAX\";i:50;s:16:\"ZC_TAGS_NAME_MAX\";i:50;s:18:\"ZC_MODULE_NAME_MAX\";i:50;s:22:\"ZC_ARTICLE_EXCERPT_MAX\";i:250;s:22:\"ZC_COMMENT_EXCERPT_MAX\";i:20;s:14:\"ZC_STATIC_MODE\";s:6:\"ACTIVE\";s:16:\"ZC_ARTICLE_REGEX\";s:18:\"{%host%}?id={%id%}\";s:13:\"ZC_PAGE_REGEX\";s:18:\"{%host%}?id={%id%}\";s:17:\"ZC_CATEGORY_REGEX\";s:34:\"{%host%}?cate={%id%}&page={%page%}\";s:15:\"ZC_AUTHOR_REGEX\";s:34:\"{%host%}?auth={%id%}&page={%page%}\";s:13:\"ZC_TAGS_REGEX\";s:34:\"{%host%}?tags={%id%}&page={%page%}\";s:13:\"ZC_DATE_REGEX\";s:36:\"{%host%}?date={%date%}&page={%page%}\";s:14:\"ZC_INDEX_REGEX\";s:22:\"{%host%}?page={%page%}\";s:18:\"ZC_ALIAS_BACK_ATTR\";s:4:\"Name\";s:15:\"ZC_SEARCH_COUNT\";i:20;s:15:\"ZC_SEARCH_REGEX\";s:40:\"{%host%}search.php?q={%q%}&page={%page%}\";s:14:\"ZC_SEARCH_TYPE\";s:6:\"single\";s:25:\"ZC_INDEX_DEFAULT_TEMPLATE\";s:5:\"index\";s:24:\"ZC_POST_DEFAULT_TEMPLATE\";s:6:\"single\";s:16:\"ZC_SIDEBAR_ORDER\";s:78:\"calendar|controlpanel|catalog|searchpanel|comments|archives|favorite|link|misc\";s:17:\"ZC_SIDEBAR2_ORDER\";s:0:\"\";s:17:\"ZC_SIDEBAR3_ORDER\";s:0:\"\";s:17:\"ZC_SIDEBAR4_ORDER\";s:0:\"\";s:17:\"ZC_SIDEBAR5_ORDER\";s:0:\"\";s:17:\"ZC_SIDEBAR6_ORDER\";s:0:\"\";s:17:\"ZC_SIDEBAR7_ORDER\";s:0:\"\";s:17:\"ZC_SIDEBAR8_ORDER\";s:0:\"\";s:17:\"ZC_SIDEBAR9_ORDER\";s:0:\"\";s:27:\"ZC_SYNTAXHIGHLIGHTER_ENABLE\";b:1;s:20:\"ZC_CODEMIRROR_ENABLE\";b:1;s:14:\"ZC_GZIP_ENABLE\";b:0;s:21:\"ZC_ADMIN_HTML5_ENABLE\";b:1;s:20:\"ZC_LOADMEMBERS_LEVEL\";i:0;s:15:\"ZC_LAST_VERSION\";s:6:\"162100\";s:20:\"ZC_HTTP_LASTMODIFIED\";b:0;s:23:\"ZC_MODULE_CATALOG_STYLE\";i:0;s:24:\"ZC_MODULE_ARCHIVES_STYLE\";i:0;s:19:\"ZC_VIEWNUMS_TURNOFF\";b:0;s:20:\"ZC_LISTONTOP_TURNOFF\";b:0;s:20:\"ZC_RELATEDLIST_COUNT\";i:10;s:18:\"ZC_RUNINFO_DISPLAY\";b:1;s:30:\"ZC_POST_ALIAS_USE_ID_NOT_TITLE\";b:0;s:21:\"ZC_COMPATIBLE_ASP_URL\";b:1;s:13:\"ZC_LARGE_DATA\";b:0;s:16:\"ZC_JS_304_ENABLE\";b:0;s:20:\"ZC_VERSION_IN_HEADER\";b:1;s:22:\"ZC_ADDITIONAL_SECURITY\";b:1;s:16:\"ZC_XMLRPC_ENABLE\";b:1;s:22:\"ZC_XMLRPC_USE_WEBTOKEN\";b:0;s:25:\"ZC_USING_CDN_GUESTIP_TYPE\";s:11:\"REMOTE_ADDR\";s:14:\"ZC_NOW_VERSION\";s:6:\"162100\";}');
INSERT INTO `zbp_config` VALUES (3, 'AppCentre', 'a:12:{s:12:\"enabledcheck\";i:0;s:9:\"checkbeta\";i:0;s:13:\"enabledevelop\";i:0;s:13:\"enablegzipapp\";i:0;s:13:\"lastchecktime\";i:1591595873;s:5:\"token\";N;s:7:\"uniq_id\";N;s:9:\"old_token\";s:4:\"true\";s:8:\"username\";s:0:\"\";s:8:\"password\";s:0:\"\";s:11:\"networktype\";s:0:\"\";s:11:\"firstdomain\";s:0:\"\";}');
INSERT INTO `zbp_config` VALUES (4, 'tpure', 'a:5:{s:11:\"PostCOLORON\";s:1:\"1\";s:9:\"PostCOLOR\";N;s:11:\"PostBGCOLOR\";N;s:14:\"PostSIDELAYOUT\";N;s:13:\"PostCUSTOMCSS\";N;}');

-- ----------------------------
-- Table structure for zbp_member
-- ----------------------------
DROP TABLE IF EXISTS `zbp_member`;
CREATE TABLE `zbp_member`  (
  `mem_ID` int(11) NOT NULL AUTO_INCREMENT,
  `mem_Guid` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `mem_Level` tinyint(4) NOT NULL DEFAULT 0,
  `mem_Status` tinyint(4) NOT NULL DEFAULT 0,
  `mem_Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `mem_Password` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `mem_Email` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `mem_HomePage` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `mem_IP` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `mem_PostTime` int(11) NOT NULL DEFAULT 0,
  `mem_Alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `mem_Intro` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `mem_Articles` int(11) NOT NULL DEFAULT 0,
  `mem_Pages` int(11) NOT NULL DEFAULT 0,
  `mem_Comments` int(11) NOT NULL DEFAULT 0,
  `mem_Uploads` int(11) NOT NULL DEFAULT 0,
  `mem_Template` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `mem_Meta` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`mem_ID`) USING BTREE,
  INDEX `zbp_mem_Name`(`mem_Name`) USING BTREE,
  INDEX `zbp_mem_Alias`(`mem_Alias`) USING BTREE,
  INDEX `zbp_mem_Level`(`mem_Level`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of zbp_member
-- ----------------------------
INSERT INTO `zbp_member` VALUES (1, '5eddd34f87439232481135', 1, 0, 'admin', '0d61397eb0256eadb0e35f0991ae5e7f', 'null@null.com', '', '127.0.0.1', 1591595855, '', '', 0, 0, 0, 0, '', '');

-- ----------------------------
-- Table structure for zbp_module
-- ----------------------------
DROP TABLE IF EXISTS `zbp_module`;
CREATE TABLE `zbp_module`  (
  `mod_ID` int(11) NOT NULL AUTO_INCREMENT,
  `mod_Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `mod_FileName` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `mod_Content` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `mod_SidebarID` int(11) NOT NULL DEFAULT 0,
  `mod_HtmlID` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `mod_Type` varchar(5) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `mod_MaxLi` int(11) NOT NULL DEFAULT 0,
  `mod_Source` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `mod_IsHideTitle` tinyint(4) NOT NULL DEFAULT 0,
  `mod_Meta` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`mod_ID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 15 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of zbp_module
-- ----------------------------
INSERT INTO `zbp_module` VALUES (1, '导航栏', 'navbar', '<li id=\"nvabar-item-index\"><a href=\"{#ZC_BLOG_HOST#}\">首页</a></li><li id=\"navbar-page-2\"><a href=\"{#ZC_BLOG_HOST#}?id=2\">留言本</a></li>', 0, 'divNavBar', 'ul', 0, 'system', 0, '');
INSERT INTO `zbp_module` VALUES (2, '日历', 'calendar', '<table id=\"tbCalendar\">\r\n    <caption><a href=\"{#ZC_BLOG_HOST#}?date=2020-5\">«</a>&nbsp;&nbsp;&nbsp;<a href=\"{#ZC_BLOG_HOST#}?date=2020-6\">2020年6月</a>&nbsp;&nbsp;&nbsp;<a href=\"{#ZC_BLOG_HOST#}?date=2020-7\">»</a></caption>\r\n    <thead><tr> <th title=\"星期一\" scope=\"col\"><small>一</small></th> <th title=\"星期二\" scope=\"col\"><small>二</small></th> <th title=\"星期三\" scope=\"col\"><small>三</small></th> <th title=\"星期四\" scope=\"col\"><small>四</small></th> <th title=\"星期五\" scope=\"col\"><small>五</small></th> <th title=\"星期六\" scope=\"col\"><small>六</small></th> <th title=\"星期日\" scope=\"col\"><small>日</small></th></tr></thead>\r\n    <tbody>\r\n    <tr>\r\n<td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td></tr><tr><td><a href=\"{#ZC_BLOG_HOST#}?date=2020-6-8\" title=\"2020-6-8 (1)\" target=\"_blank\">8</a></td><td>9</td><td>10</td><td>11</td><td>12</td><td>13</td><td>14</td></tr><tr><td>15</td><td>16</td><td>17</td><td>18</td><td>19</td><td>20</td><td>21</td></tr><tr><td>22</td><td>23</td><td>24</td><td>25</td><td>26</td><td>27</td><td>28</td></tr><tr><td>29</td><td>30</td><td class=\"pad\" colspan=\"4\"> </td>	</tr></tbody>\r\n</table>', 0, 'divCalendar', 'div', 0, 'system', 1, '');
INSERT INTO `zbp_module` VALUES (3, '控制面板', 'controlpanel', '<span class=\"cp-hello\">您好，欢迎到访网站！</span><br/><span class=\"cp-login\"><a href=\"{#ZC_BLOG_HOST#}zb_system/cmd.php?act=login\">登录后台</a></span>&nbsp;&nbsp;<span class=\"cp-vrs\"><a href=\"{#ZC_BLOG_HOST#}zb_system/cmd.php?act=misc&amp;type=vrs\">查看权限</a></span>', 0, 'divContorPanel', 'div', 0, 'system', 0, '');
INSERT INTO `zbp_module` VALUES (4, '网站分类', 'catalog', '<li><a href=\"{#ZC_BLOG_HOST#}?cate=1\">未分类</a></li>\r\n', 0, 'divCatalog', 'ul', 0, 'system', 0, '');
INSERT INTO `zbp_module` VALUES (5, '搜索', 'searchpanel', '<form name=\"search\" method=\"post\" action=\"{#ZC_BLOG_HOST#}zb_system/cmd.php?act=search\"><input type=\"text\" name=\"q\" size=\"11\" /> <input type=\"submit\" value=\"搜索\" /></form>', 0, 'divSearchPanel', 'div', 0, 'system', 0, '');
INSERT INTO `zbp_module` VALUES (6, '最新留言', 'comments', '', 0, 'divComments', 'ul', 0, 'system', 0, '');
INSERT INTO `zbp_module` VALUES (7, '文章归档', 'archives', '', 0, 'divArchives', 'ul', 0, 'system', 0, '');
INSERT INTO `zbp_module` VALUES (8, '站点信息', 'statistics', '<li>文章总数:1</li>\r\n<li>页面总数:1</li>\r\n<li>分类总数:1</li>\r\n<li>标签总数:0</li>\r\n<li>评论总数:0</li>\r\n<li>浏览总数:0</li>\r\n', 0, 'divStatistics', 'ul', 0, 'system', 0, '');
INSERT INTO `zbp_module` VALUES (9, '网站收藏', 'favorite', '<li><a href=\"https://app.zblogcn.com/\" target=\"_blank\">Z-Blog应用中心</a></li><li><a href=\"https://weibo.com/zblogcn\" target=\"_blank\">Z-Blog官方微博</a></li><li><a href=\"https://bbs.zblogcn.com/\" target=\"_blank\">ZBlogger社区</a></li>', 0, 'divFavorites', 'ul', 0, 'system', 0, '');
INSERT INTO `zbp_module` VALUES (10, '友情链接', 'link', '<li><a href=\"https://github.com/zblogcn\" target=\"_blank\" title=\"Z-Blog on Github\">Z-Blog on Github</a></li><li><a href=\"https://zbloghost.cn/\" target=\"_blank\" title=\"Z-Blog官方主机\">Z-Blog主机</a></li>', 0, 'divLinkage', 'ul', 0, 'system', 0, '');
INSERT INTO `zbp_module` VALUES (11, '图标汇集', 'misc', '<li><a href=\"https://www.zblogcn.com/\" target=\"_blank\"><img src=\"{#ZC_BLOG_HOST#}zb_system/image/logo/zblog.gif\" height=\"31\" width=\"88\" alt=\"Z-BlogPHP\" /></a></li><li><a href=\"{#ZC_BLOG_HOST#}feed.php\" target=\"_blank\"><img src=\"{#ZC_BLOG_HOST#}zb_system/image/logo/rss.png\" height=\"31\" width=\"88\" alt=\"订阅本站的 RSS 2.0 新闻聚合\" /></a></li>', 0, 'divMisc', 'ul', 0, 'system', 1, '');
INSERT INTO `zbp_module` VALUES (12, '作者列表', 'authors', '', 0, 'divAuthors', 'ul', 0, 'system', 0, '');
INSERT INTO `zbp_module` VALUES (13, '最近发表', 'previous', '', 0, 'divPrevious', 'ul', 0, 'system', 0, '');
INSERT INTO `zbp_module` VALUES (14, '标签列表', 'tags', '', 0, 'divTags', 'ul', 0, 'system', 0, '');

-- ----------------------------
-- Table structure for zbp_post
-- ----------------------------
DROP TABLE IF EXISTS `zbp_post`;
CREATE TABLE `zbp_post`  (
  `log_ID` int(11) NOT NULL AUTO_INCREMENT,
  `log_CateID` int(11) NOT NULL DEFAULT 0,
  `log_AuthorID` int(11) NOT NULL DEFAULT 0,
  `log_Tag` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `log_Status` tinyint(4) NOT NULL DEFAULT 0,
  `log_Type` int(11) NOT NULL DEFAULT 0,
  `log_Alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `log_IsTop` int(11) NOT NULL DEFAULT 0,
  `log_IsLock` tinyint(4) NOT NULL DEFAULT 0,
  `log_Title` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `log_Intro` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `log_Content` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `log_PostTime` int(11) NOT NULL DEFAULT 0,
  `log_CommNums` int(11) NOT NULL DEFAULT 0,
  `log_ViewNums` int(11) NOT NULL DEFAULT 0,
  `log_Template` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `log_Meta` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`log_ID`) USING BTREE,
  INDEX `zbp_log_TPISC`(`log_Type`, `log_PostTime`, `log_IsTop`, `log_Status`, `log_CateID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of zbp_post
-- ----------------------------
INSERT INTO `zbp_post` VALUES (1, 1, 1, '', 0, 0, '', 0, 0, '欢迎使用Z-BlogPHP！', '<p>欢迎使用Z-Blog，这是程序自动生成的文章，您可以删除或是编辑它:)</p><p>系统生成了一个留言本和一篇《欢迎使用Z-BlogPHP！》，祝您使用愉快！</p>', '<p>欢迎使用Z-Blog，这是程序自动生成的文章，您可以删除或是编辑它:)</p><p>系统生成了一个留言本和一篇《欢迎使用Z-BlogPHP！》，祝您使用愉快！</p>', 1591595855, 0, 0, '', '');
INSERT INTO `zbp_post` VALUES (2, 0, 1, '', 0, 1, '', 0, 0, '留言本', '', '这是一个留言本，是由程序自动生成的页面，您可以对其进行任意操作。', 1591595855, 0, 2, '', '');

-- ----------------------------
-- Table structure for zbp_tag
-- ----------------------------
DROP TABLE IF EXISTS `zbp_tag`;
CREATE TABLE `zbp_tag`  (
  `tag_ID` int(11) NOT NULL AUTO_INCREMENT,
  `tag_Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `tag_Order` int(11) NOT NULL DEFAULT 0,
  `tag_Type` int(11) NOT NULL DEFAULT 0,
  `tag_Count` int(11) NOT NULL DEFAULT 0,
  `tag_Alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `tag_Intro` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `tag_Template` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `tag_Meta` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`tag_ID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of zbp_tag
-- ----------------------------

-- ----------------------------
-- Table structure for zbp_upload
-- ----------------------------
DROP TABLE IF EXISTS `zbp_upload`;
CREATE TABLE `zbp_upload`  (
  `ul_ID` int(11) NOT NULL AUTO_INCREMENT,
  `ul_AuthorID` int(11) NOT NULL DEFAULT 0,
  `ul_Size` int(11) NOT NULL DEFAULT 0,
  `ul_Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `ul_SourceName` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `ul_MimeType` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `ul_PostTime` int(11) NOT NULL DEFAULT 0,
  `ul_DownNums` int(11) NOT NULL DEFAULT 0,
  `ul_LogID` int(11) NOT NULL DEFAULT 0,
  `ul_Intro` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `ul_Meta` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`ul_ID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of zbp_upload
-- ----------------------------

SET FOREIGN_KEY_CHECKS = 1;
