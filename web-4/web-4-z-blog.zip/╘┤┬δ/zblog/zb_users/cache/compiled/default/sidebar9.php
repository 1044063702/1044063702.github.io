<?php  /* Template Name:侧栏模板 */  ?>
<?php  foreach ( $sidebar9 as $module) { ?>
<?php  include $this->GetTemplate('module');  ?>
<?php }   ?>