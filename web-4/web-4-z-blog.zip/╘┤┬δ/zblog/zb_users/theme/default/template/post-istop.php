{* Template Name:列表页单条置顶文章 *}
<div class="post istop-post">
	<h2 class="post-title"><!--[{$lang['msg']['top']}]--><a href="{$article.Url}">{$article.Title}</a></h2>
</div>