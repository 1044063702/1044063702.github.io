{* Template Name:搜索页文章列表 *}
<div class="post multi">
	<h2 class="post-title"><a href="{$article.Url}">{$article.Title}</a><span class="post-date">{$article.Time()}</span></h2>
	<div class="post-body">{$article.Intro}</div>
</div>